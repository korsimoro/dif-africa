# Papua New Guinea

Continent: Oceania