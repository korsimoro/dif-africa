# Israel

Continent: Asia