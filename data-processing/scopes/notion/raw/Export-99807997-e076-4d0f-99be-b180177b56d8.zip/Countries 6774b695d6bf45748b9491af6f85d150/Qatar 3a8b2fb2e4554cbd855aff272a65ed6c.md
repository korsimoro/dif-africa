# Qatar

Continent: Asia