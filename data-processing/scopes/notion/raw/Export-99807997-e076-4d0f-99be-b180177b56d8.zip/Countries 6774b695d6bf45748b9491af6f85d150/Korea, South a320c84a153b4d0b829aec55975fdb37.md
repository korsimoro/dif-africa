# Korea, South

Continent: Asia