# Turkmenistan

Continent: Asia