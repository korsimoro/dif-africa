# United Arab Emirates

Continent: Asia