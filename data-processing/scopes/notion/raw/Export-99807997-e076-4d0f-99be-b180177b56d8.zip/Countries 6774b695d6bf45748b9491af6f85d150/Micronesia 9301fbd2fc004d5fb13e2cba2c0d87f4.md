# Micronesia

Continent: Oceania