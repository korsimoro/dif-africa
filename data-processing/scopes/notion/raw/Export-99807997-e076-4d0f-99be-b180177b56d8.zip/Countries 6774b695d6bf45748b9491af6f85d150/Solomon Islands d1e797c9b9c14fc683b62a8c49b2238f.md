# Solomon Islands

Continent: Oceania