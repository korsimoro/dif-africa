# Thailand

Continent: Asia
Related to Companies: https://www.notion.so/Korsimoro-2eb0fdf1970f494f9feef779c8c8c9b0, https://www.notion.so/Finema-59b3c494ca7c4151be49a56d1e8e9888