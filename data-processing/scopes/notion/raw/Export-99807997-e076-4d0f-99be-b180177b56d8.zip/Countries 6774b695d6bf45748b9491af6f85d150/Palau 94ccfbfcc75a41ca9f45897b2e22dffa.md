# Palau

Continent: Oceania