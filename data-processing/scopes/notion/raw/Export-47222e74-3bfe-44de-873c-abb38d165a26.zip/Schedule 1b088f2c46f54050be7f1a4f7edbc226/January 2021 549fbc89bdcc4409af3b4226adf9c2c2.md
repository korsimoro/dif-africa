# January 2021

Events: email-update, meeting
Responsibility: https://www.notion.so/Catherine-Nabbala-6acdb358b55343f09efc393335a8f7ef
When: Jan 28, 2021