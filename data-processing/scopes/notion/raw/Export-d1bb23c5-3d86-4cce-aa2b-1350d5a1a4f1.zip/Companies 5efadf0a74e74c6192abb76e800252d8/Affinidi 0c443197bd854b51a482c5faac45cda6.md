# Affinidi

Country: https://www.notion.so/Singapore-330eb4d76f884381bb9050328e2ffe7d