# Korsimoro

Country: https://www.notion.so/Thailand-77bd0ddc429e4c31b6aa036eb30379d8