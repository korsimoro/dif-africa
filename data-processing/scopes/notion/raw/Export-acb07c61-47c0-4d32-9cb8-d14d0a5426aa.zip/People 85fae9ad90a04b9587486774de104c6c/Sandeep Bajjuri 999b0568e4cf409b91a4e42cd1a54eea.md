# Sandeep Bajjuri

Responsible For: https://www.notion.so/February-2021-a3d8be1458004f5795b991c6663c71f0, https://www.notion.so/December-2020-932e3a68b1c242b4958ea8bfa6bb007f
Role: call-leadership
Tags: sandeep.b@affinidi.com