# Catherine Nabbala

Responsible For: https://www.notion.so/January-2021-549fbc89bdcc4409af3b4226adf9c2c2
Role: call-leadership
Tags: catherine@finema.co